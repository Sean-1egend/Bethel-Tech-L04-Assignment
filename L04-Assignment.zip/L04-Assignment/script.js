let decreaseBtn = document.getElementById('decreaseBtn');
let currentSize = document.getElementById('rectangle').style.width;
let currentSizeParse = parseInt(currentSize);

decreaseBtn.onclick = function () {
    
    currentSizeParse -= 10; 
    console.log(currentSizeParse);
    var currentSizePx = currentSizeParse + "px";
    console.log(currentSizePx);
    document.getElementById('rectangle').style.width = currentSizePx;
    console.log('result');

}

let increaseBtn = document.getElementById('increaseBtn');

increaseBtn.onclick = function () {

    currentSizeParse += 10;
    console.log(currentSizeParse);
    var currentSizePx = currentSizeParse + "px";
    console.log(currentSizePx);
    document.getElementById('rectangle').style.width = currentSizePx;
    console.log('result');


}